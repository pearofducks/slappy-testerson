# Crashplan Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-crashplan.png?branch=master)](https://travis-ci.org/boxen/puppet-crashplan)

Install [Crashplan](http://www.crashplan.com/) on your Mac.

## Usage

```puppet
include crashplan
```

## Required Puppet Modules

* `boxen`
